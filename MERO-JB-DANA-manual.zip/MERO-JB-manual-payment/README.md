# MERO JB — pembayaran DANA manual (starter)

## Alur
1. Pembeli memilih produk dan membuat pesanan.
2. Aplikasi menampilkan instruksi transfer DANA.
3. Pembeli menghubungi admin dengan nomor pesanan.
4. Admin memeriksa saldo masuk langsung di aplikasi DANA.
5. Admin mengubah status pesanan setelah verifikasi.

## Konfigurasi
Perlu Node.js 18+.
- Jalankan `npm install`
- Salin `.env.example` menjadi `.env`
- Isi `DANA_DISPLAY_NAME` dan `DANA_ACCOUNT_NUMBER` secara privat pada server.
- Jalankan `npm start`, lalu buka `http://localhost:3000`.

JANGAN menaruh nomor DANA pribadi di file HTML publik atau membagikan PIN/OTP.
Minta bantuan orang tua/wali untuk mengelola akun pembayaran dan data merchant.

## Batasan penting
- Ini starter untuk demonstrasi alur pesanan, bukan sistem produksi.
- Pesanan disimpan di memori dan hilang saat server restart.
- Belum ada login, admin panel aman, upload bukti, database, atau pengiriman produk otomatis.
- Jangan menganggap pesanan lunas hanya dari screenshot. Verifikasi dana masuk di aplikasi DANA.
- Untuk menerima pembayaran usaha secara resmi dan skala publik, gunakan layanan merchant/QRIS yang sesuai ketentuan penyedia.
- Penjualan akun, jasa joki, dan layanan sosial media harus mematuhi ketentuan platform terkait.
