require("dotenv").config();
const express = require("express");
const path = require("path");
const crypto = require("crypto");
const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const PORT = process.env.PORT || 3000;
const DANA_DISPLAY_NAME = process.env.DANA_DISPLAY_NAME || "Nama Penerima MERO JB";
const DANA_ACCOUNT_NUMBER = process.env.DANA_ACCOUNT_NUMBER || "Atur nomor DANA di konfigurasi server";

const PRODUCTS = [
  { id:"pulsa", name:"Pulsa", category:"Produk", price:10000 },
  { id:"data", name:"Paket Data", category:"Produk", price:15000 },
  { id:"ewallet", name:"E-Wallet", category:"Produk", price:20000 },
  { id:"game", name:"Top Up Game", category:"Produk", price:12000 },
  { id:"premium", name:"Premium Sosmed", category:"JB", price:25000 },
  { id:"akun", name:"Akun Game", category:"JB", price:50000 },
  { id:"joki", name:"Jasa Joki Game", category:"JB", price:30000 }
];

// Demo-only in-memory storage. Replace with a persistent database before public launch.
const orders = new Map();

app.get("/api/products", (_req,res) => res.json(PRODUCTS));
app.get("/api/payment-info", (_req,res) => res.json({
  method:"DANA manual",
  displayName:DANA_DISPLAY_NAME,
  accountNumber:DANA_ACCOUNT_NUMBER
}));

app.post("/api/orders", (req,res) => {
  const { productId, customerName, customerContact, destination } = req.body || {};
  const product = PRODUCTS.find(p => p.id === productId);
  if (!product) return res.status(400).json({error:"Produk tidak ditemukan."});
  if (![customerName,customerContact,destination].every(v => typeof v === "string" && v.trim())) {
    return res.status(400).json({error:"Lengkapi nama, kontak, dan tujuan pesanan."});
  }
  const orderId = "MERO-" + Date.now() + "-" + crypto.randomBytes(3).toString("hex");
  const order = {
    orderId, productId, productName:product.name, amount:product.price,
    customerName:customerName.trim().slice(0,60),
    customerContact:customerContact.trim().slice(0,80),
    destination:destination.trim().slice(0,100),
    status:"awaiting_payment", createdAt:new Date().toISOString()
  };
  orders.set(orderId,order);
  res.status(201).json({orderId,productName:product.name,amount:product.price,status:order.status});
});

// Admin endpoint is intentionally not exposed in this starter.
// Do not add a public "mark paid" button. Verify funds in the DANA app first,
// then implement an authenticated admin panel and persistent database.
app.get("/api/orders/:id", (req,res) => {
  const o=orders.get(req.params.id);
  if(!o) return res.status(404).json({error:"Pesanan tidak ditemukan (penyimpanan demo)."});
  res.json({orderId:o.orderId,productName:o.productName,amount:o.amount,status:o.status});
});
app.get("/api/health", (_req,res)=>res.json({ok:true,app:"MERO JB"}));
app.listen(PORT,()=>console.log(`MERO JB running on port ${PORT}`));
